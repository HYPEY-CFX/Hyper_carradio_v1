fx_version 'cerulean'
game 'gta5'

author 'Hyper'
description 'Standalone Car Radio Script'

ui_page 'web/dist/index.html'

client_scripts {
    'client/main.js'
}

server_scripts {
    'server/main.js'
}

files {
    'web/dist/index.html',
    'web/dist/static/**/*',
    'web/dist/media/*'
}
