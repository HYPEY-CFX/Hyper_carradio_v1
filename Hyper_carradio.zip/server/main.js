// --- Car Radio Server Logic (Standalone) ---

const ServerActiveRadios = {}; // { netId: { videoId, title } }

RegisterNetEvent('Hyper_carradio:server:playRadio');
onNet('Hyper_carradio:server:playRadio', (netId, videoId, title, volume) => {
    ServerActiveRadios[netId] = {
        videoId: videoId,
        title: title,
        volume: volume || 100,
        isPaused: false,
        currentTime: 0
    };
    console.log(`[Hyper CarRadio] Vehicle ${netId} playing: ${title}`);
    TriggerClientEvent('Hyper_carradio:client:syncRadio', -1, netId, videoId, title, volume || 100, false, 0);
});

onNet('Hyper_carradio:server:toggleRadioPause', (netId, isPaused) => {
    if (ServerActiveRadios[netId]) {
        ServerActiveRadios[netId].isPaused = isPaused;
        TriggerClientEvent('Hyper_carradio:client:toggleRadioPause', -1, netId, isPaused);
    }
});

onNet('Hyper_carradio:server:updateRadioTime', (netId, time) => {
    if (ServerActiveRadios[netId]) {
        ServerActiveRadios[netId].currentTime = time;
    }
});

RegisterNetEvent('Hyper_carradio:server:stopRadio');
onNet('Hyper_carradio:server:stopRadio', (netId) => {
    if (ServerActiveRadios[netId]) {
        delete ServerActiveRadios[netId];
        TriggerClientEvent('Hyper_carradio:client:stopRadio', -1, netId);
    }
});

onNet('Hyper_carradio:server:updateRadioVolume', (netId, volume) => {
    if (ServerActiveRadios[netId]) {
        ServerActiveRadios[netId].volume = volume;
        TriggerClientEvent('Hyper_carradio:client:updateRadioVolume', -1, netId, volume);
    }
});

// Sync radios to newly connected players
on('esx:playerLoaded', (source, xPlayer) => {
    const _source = source;
    for (const [netId, radio] of Object.entries(ServerActiveRadios)) {
        TriggerClientEvent('Hyper_carradio:client:syncRadio', _source, parseInt(netId), radio.videoId, radio.title, radio.volume || 100, radio.isPaused, radio.currentTime);
    }
});
