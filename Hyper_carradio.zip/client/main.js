// --- Car Radio Client Logic (Standalone) ---

const ActiveRadios = {}; // { netId: { videoId, title } }
let radioOpen = false;

// 1. Key Mapping (Insert)
RegisterCommand('openCarRadio', () => {
    const playerPed = PlayerPedId();
    if (IsPedInAnyVehicle(playerPed, false)) {
        const vehicle = GetVehiclePedIsIn(playerPed, false);
        // Optional: Check if driver or passenger can control
        if (GetPedInVehicleSeat(vehicle, -1) === playerPed || GetPedInVehicleSeat(vehicle, 0) === playerPed) {
            radioOpen = true;
            SetNuiFocus(true, true);
            const netId = NetworkGetNetworkIdFromEntity(vehicle);
            SendNUIMessage({
                type: 'openRadio',
                visible: true,
                netId: netId
            });
        }
    }
}, false);
RegisterKeyMapping('openCarRadio', 'Open Car Radio', 'keyboard', 'INSERT');

// 2. NUI Callbacks
RegisterNuiCallbackType('closeRadio');
on('__cfx_nui:closeRadio', (data, cb) => {
    radioOpen = false;
    SetNuiFocus(false, false);
    cb('ok');
});

// 3. Server Events (Sync)
onNet('Hyper_carradio:client:syncRadio', (netId, videoId, title, volume, isPaused, time) => {
    ActiveRadios[netId] = {
        videoId,
        title,
        userVolume: volume || 100,
        isPaused: isPaused || false,
        currentTime: time || 0
    };

    // Create sound in NUI
    SendNUIMessage({
        type: 'createSound',
        data: {
            netId: netId,
            videoId: videoId,
            title: title,
            volume: 0
        }
    });

    // If seek time provided, tell NUI after a short delay (ensure player created)
    if (time && time > 0) {
        setTimeout(() => {
            SendNUIMessage({ type: 'seekRadio', data: { netId, time } });
            if (isPaused) {
                SendNUIMessage({ type: 'pauseRadio', data: { netId } });
            }
        }, 1500);
    }
});

onNet('Hyper_carradio:client:toggleRadioPause', (netId, isPaused) => {
    if (ActiveRadios[netId]) {
        ActiveRadios[netId].isPaused = isPaused;
        SendNUIMessage({
            type: isPaused ? 'pauseRadio' : 'resumeRadio',
            data: { netId }
        });
    }
});

onNet('Hyper_carradio:client:updateRadioVolume', (netId, volume) => {
    if (ActiveRadios[netId]) {
        ActiveRadios[netId].userVolume = volume;
    }
});

onNet('Hyper_carradio:client:stopRadio', (netId) => {
    if (ActiveRadios[netId]) {
        delete ActiveRadios[netId];
        SendNUIMessage({
            type: 'destroySound',
            data: { netId: netId }
        });
    }
});

RegisterNuiCallbackType('updateRadioVolume');
on('__cfx_nui:updateRadioVolume', (data, cb) => {
    const { volume } = data;
    const playerPed = PlayerPedId();
    const vehicle = GetVehiclePedIsIn(playerPed, false);
    if (vehicle) {
        const netId = NetworkGetNetworkIdFromEntity(vehicle);
        if (ActiveRadios[netId]) {
            ActiveRadios[netId].userVolume = volume;
        }
        emitNet('Hyper_carradio:server:updateRadioVolume', netId, volume);
    }
    cb('ok');
});

// 4. Audio Loop (Distance & Volume & Occlusion)
const MAX_DISTANCE = 40.0;
const FADE_DISTANCE = 5.0; // Full volume within 5 meters

setInterval(() => {
    const playerPed = PlayerPedId();
    const playerCoords = GetEntityCoords(playerPed);
    const volumes = {};
    let hasUpdates = false;

    // Optimize: if no radios, skip
    if (Object.keys(ActiveRadios).length === 0) return;

    for (const [netIdStr, radio] of Object.entries(ActiveRadios)) {
        const netId = parseInt(netIdStr);
        // Check if entity exists
        if (!NetworkDoesNetworkIdExist(netId)) {
            volumes[netId] = 0;
            hasUpdates = true;
            continue;
        }

        const vehicle = NetworkGetEntityFromNetworkId(netId);
        if (!DoesEntityExist(vehicle)) {
            volumes[netId] = 0;
            hasUpdates = true;
            continue;
        }

        const vehCoords = GetEntityCoords(vehicle);
        const distance = GetDistanceBetweenCoords(playerCoords[0], playerCoords[1], playerCoords[2], vehCoords[0], vehCoords[1], vehCoords[2], true);

        let volumeMultiplier = 0;

        // If inside the vehicle, base 1.0 (100%)
        if (IsPedInVehicle(playerPed, vehicle, false)) {
            // Inside the source vehicle: Perfect clarity
            volumeMultiplier = 1.0;
        } else {
            // Outside or in a different vehicle
            if (distance < MAX_DISTANCE) {
                let occlusionFactor = 1.0;

                // 1. Source Vehicle Occlusion (Is the car playing music closed?)
                let sourceDoorsOpen = false;
                for (let i = 0; i < 6; i++) {
                    if (GetVehicleDoorAngleRatio(vehicle, i) > 0.1) {
                        sourceDoorsOpen = true;
                        break;
                    }
                }

                if (!sourceDoorsOpen) {
                    occlusionFactor *= 0.10; // Muffled 10% if source car is closed (quieter)
                }

                // 2. Player's own vehicle Occlusion (Are we inside another closed car?)
                const playerVeh = GetVehiclePedIsIn(playerPed, false);
                if (playerVeh !== 0 && playerVeh !== vehicle) {
                    let playerDoorsOpen = false;
                    for (let i = 0; i < 6; i++) {
                        if (GetVehicleDoorAngleRatio(playerVeh, i) > 0.1) {
                            playerDoorsOpen = true;
                            break;
                        }
                    }
                    if (!playerDoorsOpen) {
                        occlusionFactor *= 0.3; // Even more muffled (30% multiplier)
                    }
                }

                // 3. Distance Falloff
                let distanceFactor = 0;
                if (distance < FADE_DISTANCE) {
                    distanceFactor = 1.0;
                } else {
                    distanceFactor = (1 - (distance - FADE_DISTANCE) / (MAX_DISTANCE - FADE_DISTANCE));
                }

                volumeMultiplier = distanceFactor * occlusionFactor;
            }
        }

        // Final Volume = Multiplier * User Set Volume (0-100)
        const userVol = radio.userVolume || 100;
        const finalVolume = Math.floor(volumeMultiplier * userVol);
        volumes[netId] = finalVolume;
        hasUpdates = true;
    }

    if (hasUpdates) {
        SendNUIMessage({
            type: 'updateVolumes',
            data: volumes
        });
    }
}, 250);

// NUI Callbacks for Radio
RegisterNuiCallbackType('playRadio');
on('__cfx_nui:playRadio', (data, cb) => {
    const { videoId, title, volume } = data;
    const playerPed = PlayerPedId();
    const vehicle = GetVehiclePedIsIn(playerPed, false);

    if (vehicle) {
        const netId = NetworkGetNetworkIdFromEntity(vehicle);
        emitNet('Hyper_carradio:server:playRadio', netId, videoId, title, volume || 100);
        cb({ netId: netId }); // Return netId to UI
        return;
    }
    cb('ok');
});

RegisterNuiCallbackType('stopRadio');
on('__cfx_nui:stopRadio', (data, cb) => {
    const playerPed = PlayerPedId();
    const vehicle = GetVehiclePedIsIn(playerPed, false);
    if (vehicle) {
        const netId = NetworkGetNetworkIdFromEntity(vehicle);
        emitNet('Hyper_carradio:server:stopRadio', netId);
    }
    cb('ok');
});

RegisterNuiCallbackType('toggleRadioPause');
on('__cfx_nui:toggleRadioPause', (data, cb) => {
    const { isPaused } = data;
    const playerPed = PlayerPedId();
    const vehicle = GetVehiclePedIsIn(playerPed, false);
    if (vehicle) {
        const netId = NetworkGetNetworkIdFromEntity(vehicle);
        emitNet('Hyper_carradio:server:toggleRadioPause', netId, isPaused);
    }
    cb('ok');
});

RegisterNuiCallbackType('updateRadioTime');
on('__cfx_nui:updateRadioTime', (data, cb) => {
    const { time } = data;
    const playerPed = PlayerPedId();
    const vehicle = GetVehiclePedIsIn(playerPed, false);
    if (vehicle) {
        const netId = NetworkGetNetworkIdFromEntity(vehicle);
        emitNet('Hyper_carradio:server:updateRadioTime', netId, time);
    }
    cb('ok');
});

// Periodic Sync: Owner reports current time to server
setInterval(() => {
    const playerPed = PlayerPedId();
    const vehicle = GetVehiclePedIsIn(playerPed, false);
    if (vehicle) {
        const netId = NetworkGetNetworkIdFromEntity(vehicle);
        const radio = ActiveRadios[netId];
        // If we are in the driver seat or owner, report time
        if (radio && GetPedInVehicleSeat(vehicle, -1) === playerPed) {
            // UI time updates
        }
    }
}, 5000);

RegisterNuiCallbackType('reportPlayTime');
on('__cfx_nui:reportPlayTime', (data, cb) => {
    const { time } = data;
    const playerPed = PlayerPedId();
    const vehicle = GetVehiclePedIsIn(playerPed, false);
    if (vehicle && GetPedInVehicleSeat(vehicle, -1) === playerPed) {
        const netId = NetworkGetNetworkIdFromEntity(vehicle);
        emitNet('Hyper_carradio:server:updateRadioTime', netId, time);
    }
    cb('ok');
});
